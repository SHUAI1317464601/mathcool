# Insert your code here.

def factorial(N):
    d=1
    for i in range(N+1):
        if N==1 or N==0:
            d=1
        else:
            d=i*d
    return (d)











